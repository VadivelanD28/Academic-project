# Face Detection Attendance System

This Project will help in learning
<li> Working with kivi 
<li> Basic OOPs concept of python
<li> Multithreading in python
<li> OpenCV
  
  
Contributions are always appriciated
